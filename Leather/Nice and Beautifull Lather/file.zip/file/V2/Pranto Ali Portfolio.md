[PAPranto Ali](#top)

[About](#about)[Skills](#skills)[Projects](#projects)[Journey](#journey)[Certificates](#certificates)[Contact](#contact)

### Mode

### Colour palette

### Surface

### Grain strength

Leather stitching[x]

Web designer & developer · Dhaka, Bangladesh

# Md. Pranto Ali

I build school management systems, POS software, websites and RFID attendance devices that run every day without fuss. Honest work, clear communication, and details that hold up in real use.

[View projects](#projects) [Get in touch](#contact)

B.Sc. CSE

IUBAT, currently studying

3.72 / 4.00

Diploma in Computer Technology, 2023

6 months

Internship at Kodeeo Limited

Md. Pranto Ali

PA

About

## Careful work, built to last

I like turning a plain request into a tool people use every day.

I am a Computer Science and Engineering student at IUBAT with a diploma in Computer Technology. My work covers software for schools and shops, public websites, and small hardware devices that read RFID cards and fingerprints.

I am interested in growing my professional career and helping create a positive learning environment. I am honest, I work hard for the people I build for, and I keep learning new tools and technologies.

Location

Uttara Sector 10, Dhaka-1230

Hometown

Kushtia, Khulna Division

Languages

Bengali, English

Away from the screen

Reading storybooks, exploring new software, listening to music

Skills

## What I work with

## Projects

Journey

## Experience & education

## Certificates

Contact

## Have a project in mind?

Tell me what you need to run: a school, a shop, a gate or a website. I will reply with a clear plan. References are available on request.

Email

prantoislamnt51@gmail.com

Phone

+8801979728818

Address

House 18, Road 10, Uttara Sector 10, Dhaka-1230

© 2026 Md. Pranto AliDhaka, Bangladesh