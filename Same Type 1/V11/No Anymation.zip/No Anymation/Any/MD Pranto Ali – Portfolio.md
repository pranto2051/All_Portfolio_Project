[Pranto*.*](#home)

PA

**MD Pranto Ali**Open to work

[Pranto*.*](#home)

CSE student · Uttara, Dhaka

# MD Pranto Ali

I’m a

I turn ideas into practical digital solutions: websites, automation, databases and smart IoT devices. Honest, hard-working and always learning.

[View projects](#projects)[Hire me](#contact)

PA

**0**Diploma CGPA

**0**Demo projects

**0**Certificates

**0**Years in retail

## 01 · Who I amAbout me

### Bio

I’m a Computer Science and Engineering student at IUBAT – International University of Business Agriculture and Technology, with a strong passion for software development, web technologies, automation, databases and emerging technologies.

I enjoy learning new technologies, solving real-world problems and turning ideas into practical digital solutions. I am honest and prepared to work hard to achieve my goals.

### Based in

Sector 10, Uttara, Dhaka

### Where I’m heading

Full-Stack

Software Eng.

Automation

AI

IoT

### Languages & interests

BengaliEnglishReadingLearning new skillsExploring technologyMusic

## 02 · What I useTechnical skills

Windows XP to 11LinuxMS Office 2007/2013/2016Adobe Photoshop 7 / CS6CanvaPC hardware configurationInternet, email, LAN & wireless

## 03 · What I buildProjects

[View demo ↗](#)

## 04 · My pathEducation & experience

## 05 · Proof of learningCertificates

## 06 · Say helloGet in touch

### Send a message

**You**Your message will appear here as you type…

You

### Let’s build something together

Have a project, an internship or an idea? I’d love to hear about it.

[Email me directly](#)

### Contact information

Location**House 18, Road 10, Sector 10, Uttara, Dhaka-1230**

Phone

Email

### Find me online

© MD Pranto Ali